 package dao;

import java.util.ArrayList;

import java.sql.ResultSet;

import models.Book;
import models.ConnectionSqlite;

public class CartDao {
    public static ArrayList<Book> listBooks = new ArrayList<>();
    public static ArrayList<Book> cartBooks = new ArrayList<>();
    
    public CartDao() {
    	String sql = "Select * From Book";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					book.setQuantity(1);
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
    }
    
    public ArrayList<Book> getListBooks() {
		return listBooks;
	}

	public void setListBooks(ArrayList<Book> listBooks) {
		CartDao.listBooks = listBooks;
	}

	public  ArrayList<Book> getCartBooks() {
		return cartBooks;
	}

	public void setCartBooks(ArrayList<Book> cartBooks) {
		CartDao.cartBooks = cartBooks;
	}
	
    
	
	public ArrayList<Book> showBooks_bestSeller(){
		 String sql = "Select * From Book ORDER BY RANDOM() LIMIT 15";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}
        public ArrayList<Book> showBooks_art(){
		 String sql = "Select * From Book WHERE Category ='Art' ORDER BY RANDOM() LIMIT 15";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}
        public ArrayList<Book> showBooks_study(){
		 String sql = "Select * From Book ORDER BY RANDOM() LIMIT 15";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}
       
	
	public ArrayList<Book> showBooks_best2019(){
		 String sql = "SELECT * FROM Book ORDER BY RANDOM() LIMIT 15";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}
        public ArrayList<Book> showBooks_lifestyle(){
		 String sql = "Select * From Book ORDER BY RANDOM() LIMIT 15";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}public ArrayList<Book> showBooks_novel(){
		 String sql = "Select * From Book ORDER BY RANDOM() LIMIT 15";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}
	
	public ArrayList<Book> showBooks_newRelease(){
		 String sql = "select * from Book order by BID desc LIMIT 15;";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}
	
	public ArrayList<Book> showBooks_children(){
		 String sql = "Select * From Book LIMIT 15";
		 listBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					listBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return listBooks;
	}
	
	
	
	public boolean addToCart(String BID) {
    	for (int i=0; i <listBooks.size(); i++) {
    		if(listBooks.get(i).getBID().equals(BID)) {
    			cartBooks.add(listBooks.get(i));
    			return true;
    		}
    	}
    	return false;
    }
    
    public boolean deleteFromCart(String BID) {
    	for (int i=0; i <cartBooks.size(); i++) {
    		if(cartBooks.get(i).getBID().equals(BID)) {
    			cartBooks.remove(i);
    			return true;
    		}
    	}
    	return false;
    }
}

