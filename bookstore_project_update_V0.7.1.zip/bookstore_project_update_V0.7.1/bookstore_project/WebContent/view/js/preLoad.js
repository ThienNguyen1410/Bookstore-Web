$(window).load(function() {
		    		$(".se-pre-con").delay(2000).fadeOut(1000);
		    	});