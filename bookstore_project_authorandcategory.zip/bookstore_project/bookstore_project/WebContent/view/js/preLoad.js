$(window).load(function() {
		    		$(".se-pre-con").delay(900).fadeOut(1000);
		    	});