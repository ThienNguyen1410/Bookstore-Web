package dao;

import java.util.ArrayList;

import java.sql.ResultSet;

import models.Book;
import models.ConnectionSqlite;

public class AuthorDao {
    public static ArrayList<Book> authorBooks = new ArrayList<>();
  
    
    public AuthorDao() {
    	String sql = "Select * From Book ";
		 authorBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					book.setQuantity(1);
					authorBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
    }
    public ArrayList<Book> getAuthorBooks() {
		return authorBooks;
	}

	public void setAuthorBooks(ArrayList<Book> authorBooks) {
		AuthorDao.authorBooks = authorBooks;
	}
        public ArrayList<Book> showBooks_author( String Bauthor){
		 String sql = "Select * From Book WHERE Bauthor = '"+Bauthor+"'";
		 authorBooks = new ArrayList<>();
			try {
				ResultSet rs = new ConnectionSqlite().choseData(sql);
				 
				while(rs.next()){
					Book book = new Book();
					book.setBID(rs.getString(1));
					book.setBtitle(rs.getString(2));
					book.setBauthor(rs.getString(3));
					book.setBprice(rs.getDouble(4));
					book.setImage(rs.getString(5));
					authorBooks.add(book);
				}rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		
		return authorBooks;
	}
}