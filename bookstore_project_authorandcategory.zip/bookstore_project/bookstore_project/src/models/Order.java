package models;

public class Order {
     private String OID;
     private double OBill;
	public String getOID() {
		return OID;
	}
	public void setOID(String oID) {
		OID = oID;
	}
	public Double getOBill() {
		return OBill;
	}
	public void setOBill(double OBill) {
		this.OBill = OBill;
	}
     
     
}
