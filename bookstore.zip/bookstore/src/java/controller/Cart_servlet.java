package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CartDao;
import models.Customer;


@WebServlet(urlPatterns ="/Cart_servlet")
public class Cart_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public Cart_servlet() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String BID = request.getParameter("BID");
		
		HttpSession session=request.getSession();
		Customer cus=(Customer) session.getAttribute("user");
		if(cus!=null) {
			new CartDao().addToCart(BID);
			response.sendRedirect("view/cart_user.jsp");
		}
		else {
			response.sendRedirect("view/login_signin.jsp");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
